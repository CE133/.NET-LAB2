using System;
using System.Reflection;
[assembly:AssemblyVersion("1.0.0.0")]

namespace Calc
{
    public class Calculator
    {
        public float add(float a,float b)
        {
            return a+b+1000;
        }
        public float sub(float a,float b)
        {
            return a-b+1000;
        }
        public float div(float a,float b)
        {
            return a/b+1000;
        }
        public float mul(float a,float b)
        {
            return a*b+1000;
        }
    } 
}