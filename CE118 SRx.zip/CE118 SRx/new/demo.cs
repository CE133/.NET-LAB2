using System;

namespace demo
{
    public class message
    {
        public string msg()
        {
            return "Muchas Gracias! hola";
        }

    } 
}