using System;
using demo;

namespace main
{
    public class Hola
    {
        public static void Main(string[] args)
        {
           message m = new message();
           Console.WriteLine(m.msg());
        }
    } 
}