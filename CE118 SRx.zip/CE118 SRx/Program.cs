using System;
using Calc;

namespace Program
{
    public class Calcu
    {
        public static void Main(string[] args)
        {
            Calculator cal=new Calculator();
            Console.WriteLine("Enter 1st number: ");
            float a =float.Parse(Console.ReadLine());
            Console.WriteLine("Enter 2st number: ");
            float b =float.Parse(Console.ReadLine());
            Console.WriteLine(a+" + " +b+" : "+cal.add(a,b));
            Console.WriteLine(a+" - " +b+" : "+cal.sub(a,b));
            Console.WriteLine(a+" / " +b+" : "+cal.div(a,b));
            Console.WriteLine(a+" * " +b+" : "+cal.mul(a,b));
            Console.ReadLine();
        }
    } 
}